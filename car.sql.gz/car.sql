-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2022 at 06:06 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin@', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `carid` int(50) NOT NULL,
  `bookid` int(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` int(100) NOT NULL,
  `address` varchar(50) NOT NULL,
  `fromdest` varchar(50) NOT NULL,
  `todest` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`carid`, `bookid`, `firstname`, `email`, `mobile`, `address`, `fromdest`, `todest`, `date`) VALUES
(1, 1, 'dnyaneshvar jadhav', 'dnyaneshja9783@gmail.com', 2147483647, 'nijampur', 'Nashik', 'Pune', '2022-02-17'),
(1, 2, 'himanshu sonawane', 'himanshu@12gmail.com', 2147483647, 'bhadne', 'Nashik', 'Mumbai', '2022-02-01'),
(1, 3, 'himanshu sonawane', 'himanshu@12gmail.com', 2147483647, 'bhadne', 'Nashik', 'Mumbai', '2022-02-01'),
(1, 4, 'dineshjadhav', 'dinu@12gmail.com', 2147483647, 'nijampur', 'Pune', 'Pune', '2022-02-02');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `userid` int(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mobile` int(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`userid`, `firstname`, `lastname`, `address`, `mobile`, `gender`, `username`, `password`, `email`) VALUES
(1, 'dnyaneshvar', 'jadhav', 'nijampur', 2147483647, 'Male', 'dnyanesh@', 'dnyanesh', 'dnyaneshja9783@gmail.com'),
(2, 'jitendra', 'jadhav', 'nijampur', 2147483647, 'Male', 'jitu@', 'jitu', 'jitu@12gmail.com'),
(3, 'himanshu', 'sonawane', 'bhadne', 2147483647, 'Male', 'himanshu@', 'himanshu', 'himanshu@12gmail.com'),
(4, 'dinesh', 'jadhav', 'khudane', 2147483647, 'Male', 'dinu@', 'dinu', 'dinu@12gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookid`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `userid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
